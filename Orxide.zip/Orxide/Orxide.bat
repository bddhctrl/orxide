@echo off
cd /d "%~dp0"
if "%1"=="fullscreen" goto :fullscreen

REM Launch in fullscreen mode
start "" /max "%SystemRoot%\system32\cmd.exe" /c "%~f0" fullscreen
exit

:fullscreen
REM Set fullscreen mode via VBS
mshta "javascript:var sh=new ActiveXObject('WScript.Shell');sh.SendKeys('{F11}');close();"

REM Hide cursor and set initial colors
for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"

REM Play sound.mp3 in background (place sound.mp3 next to this .bat file)
set "soundfile=%~dp0sound.mp3"
if exist "%soundfile%" (
    (
        echo Set Sound = CreateObject("WMPlayer.OCX.7"^)
        echo Sound.URL = "%soundfile%"
        echo Sound.Controls.play
        echo do while Sound.currentmedia.duration = 0
        echo   wscript.sleep 100
        echo loop
        echo wscript.sleep ^(int(Sound.currentmedia.duration^)+1^)*1000
    ) > "%temp%\skeleton_sound.vbs"
    start /min "" "%temp%\skeleton_sound.vbs"
)

color 0C

:loop
REM Flash to red background
cls
echo %ESC%[41m
echo.
echo.
echo.
echo                            .--~~,,__                               
echo :-....,-------`~`-,,___                                     
echo        ,-~,^,-~~~-,,  ``~-,,___                               
echo     ,~`,,               ``~--,,,                             
echo   ,`-`  `                      `~~-,,                       
echo ,`                                             ,,~~--,,     
echo/`                                              ,`     `~,    
echo:                       ,-~~--,                  :         :   
echo:                      :`    `\                 :         :   
echo :    ,                 :     :`,_      ,       :    ,    :   
echo  \, `~-,_                `~--~`   `~-,_       :   /    /    
echo   `-,   `~-,_                           `~--_`  `~,`/     
echo      `,     `~--,,,___               ___,,,--~`     `      
echo        `~-,_          ``~~~~~~~```           `~,           
echo            `~-,                              ,~`           
echo               `,,                        ,,~`             
echo                 ``~-,,              ,,-~~`                
echo                       ```--,,,,,---``                     
echo %ESC%[40m

REM Beep on red flash
echo ^G
ping -n 1 -w 300 127.0.0.1 >nul

REM Flash to black background
cls
echo %ESC%[40m
echo.
echo.
echo.
echo                            .--~~,,__                               
echo :-....,-------`~`-,,___                                     
echo        ,-~,^,-~~~-,,  ``~-,,___                               
echo     ,~`,,               ``~--,,,                             
echo   ,`-`  `                      `~~-,,                       
echo ,`                                             ,,~~--,,     
echo/`                                              ,`     `~,    
echo:                       ,-~~--,                  :         :   
echo:                      :`    `\                 :         :   
echo :    ,                 :     :`,_      ,       :    ,    :   
echo  \, `~-,_                `~--~`   `~-,_       :   /    /    
echo   `-,   `~-,_                           `~--_`  `~,`/     
echo      `,     `~--,,,___               ___,,,--~`     `      
echo        `~-,_          ``~~~~~~~```           `~,           
echo            `~-,                              ,~`           
echo               `,,                        ,,~`             
echo                 ``~-,,              ,,-~~`                
echo                       ```--,,,,,---``                     

ping -n 1 -w 300 127.0.0.1 >nul
goto loop